package com.example.bankline_android.domain

enum class TipoMovimentacao {
    RECEITA, DESPESA

}
