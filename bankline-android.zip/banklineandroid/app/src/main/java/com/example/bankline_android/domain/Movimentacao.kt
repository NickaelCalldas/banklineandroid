package com.example.bankline_android.domain

data class Movimentacao(
    val id: Int,
    val dataHora:String,
    val descrico: String,
    val valor: Double,
    val tipo: TipoMovimentacao,
    // TODO "Mapear -> idConta -> idCorrentista"
    val idCorrentista: Int


)
